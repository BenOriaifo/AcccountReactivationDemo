// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { AccountReactivationComponent } from './account-reactivation.component';

// describe('AccountReactivationComponent', () => {
//   let component: AccountReactivationComponent;
//   let fixture: ComponentFixture<AccountReactivationComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ AccountReactivationComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AccountReactivationComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });

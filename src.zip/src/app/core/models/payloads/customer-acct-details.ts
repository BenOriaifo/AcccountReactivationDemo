export class CustomerLoanDetails {
    AccountNumber: string;
    AccountName: string;
    AvailableBalance: string;
    LoanAmountValue: string;
    OutstandingBalance: string;
    AccountSchemeType: string;
    AccountType: string;

}

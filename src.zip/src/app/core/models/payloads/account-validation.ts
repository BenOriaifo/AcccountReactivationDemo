export class AccountValidation {
    accountNumber: string;
    phoneNumber: string;
}
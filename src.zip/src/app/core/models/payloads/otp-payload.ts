export class OTPPayload {
    userId: string;
    cifId: string;
    reasonCode: string;
    reasonDescription: string;
}
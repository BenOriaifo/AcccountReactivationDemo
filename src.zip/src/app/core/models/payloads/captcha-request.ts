export interface Captcha
{
    capchaInstanceId: string;
    capchaCode: string;
}

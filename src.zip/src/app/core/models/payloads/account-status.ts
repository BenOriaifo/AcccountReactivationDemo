export enum AccountStatus{
    Active = 'A',
    Inactive = 'I',
    Dormant = 'D'
}
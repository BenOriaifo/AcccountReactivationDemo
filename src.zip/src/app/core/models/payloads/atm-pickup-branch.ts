export class PickupBranch {
    // BranchId: string;
    // BranchState: string;
    // BranchName: string;
    // Address: string;
    SOL_ID: string;
    Branch_Name: string;
}

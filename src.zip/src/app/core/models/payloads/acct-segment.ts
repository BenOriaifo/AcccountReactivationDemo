export enum AccountSegment {
    PersonalAccount = 'PB-PERSONAL BANKING'
}
export const _banksList = [

        {
            SOL_ID: '1',
            Branch_Name: 'ABA MAIN'
        },
        {
            SOL_ID: '2',
            Branch_Name: 'ABA MARKET'
        },
        {
            SOL_ID: '4',
            Branch_Name: 'ABA ROAD BUILDING'
        },
        {
            SOL_ID: '5',
            Branch_Name: 'ABAKALIKI'
        },
        {
            SOL_ID: '6',
            Branch_Name: 'ABEOKUTA'
        },
        {
            SOL_ID: '7',
            Branch_Name: 'ABUJA SERVICE CENTRE'
        },
        {
            SOL_ID: '8',
            Branch_Name: 'ABUJA-NNPC'
        },
        {
            SOL_ID: '9',
            Branch_Name: 'ABULE-EGBA'
        },
        {
            SOL_ID: '11',
            Branch_Name: 'ADETOKUNBO ADEMOLA'
        },
        {
            SOL_ID: '12',
            Branch_Name: 'ADO EKITI'
        },
        {
            SOL_ID: '13',
            Branch_Name: 'AFRIBANK STREET'
        },
        {
            SOL_ID: '14',
            Branch_Name: 'AGBARA'
        },
        {
            SOL_ID: '15',
            Branch_Name: 'AGEGE MINI'
        },
        {
            SOL_ID: '16',
            Branch_Name: 'AGODI GATE MINI'
        },
        {
            SOL_ID: '17',
            Branch_Name: 'AGUDA'
        },
        {
            SOL_ID: '18',
            Branch_Name: 'AHMADU BELLO WAY'
        },
        {
            SOL_ID: '19',
            Branch_Name: 'AIRPORT ROAD - WARRI'
        },
        {
            SOL_ID: '21',
            Branch_Name: 'AJAH MINI'
        },
        {
            SOL_ID: '23',
            Branch_Name: 'AJOSE ADEOGUN BRANCH'
        },
        {
            SOL_ID: '24',
            Branch_Name: 'AKOKA'
        },
        {
            SOL_ID: '25',
            Branch_Name: 'AKURE'
        },
        {
            SOL_ID: '26',
            Branch_Name: 'ALABA'
        },
        {
            SOL_ID: '27',
            Branch_Name: 'ALAUSA'
        },
        {
            SOL_ID: '28',
            Branch_Name: 'ALESHINLOYE MINI'
        },
        {
            SOL_ID: '29',
            Branch_Name: 'ALLEN AVENUE'
        },
        {
            SOL_ID: '30',
            Branch_Name: 'ARIARIA MINI'
        },
        {
            SOL_ID: '31',
            Branch_Name: 'ARTILLERY'
        },
        {
            SOL_ID: '32',
            Branch_Name: 'ASABA'
        },
        {
            SOL_ID: '33',
            Branch_Name: 'AWKA'
        },
        {
            SOL_ID: '34',
            Branch_Name: 'AWOLOWO ROAD'
        },
        {
            SOL_ID: '35',
            Branch_Name: 'BALOGUN BUSINESS ASSOCIATION'
        },
        {
            SOL_ID: '36',
            Branch_Name: 'BAUCHI'
        },
        {
            SOL_ID: '37',
            Branch_Name: 'BAYERO UNIVERSITY KANO'
        },
        {
            SOL_ID: '38',
            Branch_Name: 'BENIN CITY'
        },
        {
            SOL_ID: '39',
            Branch_Name: 'BROAD STREET BRANCH'
        },
        {
            SOL_ID: '40',
            Branch_Name: 'CALABAR'
        },
        {
            SOL_ID: '41',
            Branch_Name: 'CHALLENGE'
        },
        {
            SOL_ID: '42',
            Branch_Name: 'DAMATURU'
        },
        {
            SOL_ID: '43',
            Branch_Name: 'DEIDE MINI'
        },
        {
            SOL_ID: '44',
            Branch_Name: 'DUTSE'
        },
        {
            SOL_ID: '45',
            Branch_Name: 'EGBEDA'
        },
        {
            SOL_ID: '46',
            Branch_Name: 'EJIGBO'
        },
        {
            SOL_ID: '47',
            Branch_Name: 'EKET BRANCH'
        },
        {
            SOL_ID: '48',
            Branch_Name: 'ELEME CASH CENTER'
        },
        {
            SOL_ID: '49',
            Branch_Name: 'ENUGU'
        },
        {
            SOL_ID: '50',
            Branch_Name: 'FESTAC'
        },
        {
            SOL_ID: '51',
            Branch_Name: 'GARKI (AREA 3)'
        },
        {
            SOL_ID: '52',
            Branch_Name: 'GARKI MODEL MINI'
        },
        {
            SOL_ID: '55',
            Branch_Name: 'GBAGADA'
        },
        {
            SOL_ID: '57',
            Branch_Name: 'GBAGI (IBADAN)'
        },
        {
            SOL_ID: '59',
            Branch_Name: 'GBOKO'
        },
        {
            SOL_ID: '62',
            Branch_Name: 'GOMBE'
        },
        {
            SOL_ID: '63',
            Branch_Name: 'GUSAU'
        },
        {
            SOL_ID: '64',
            Branch_Name: 'GWAGWALADA'
        },
        {
            SOL_ID: '65',
            Branch_Name: 'HEAD OFFICE BRANCH -IBTC PLACE'
        },
        {
            SOL_ID: '66',
            Branch_Name: 'HERBERT MACAULAY'
        },
        {
            SOL_ID: '67',
            Branch_Name: 'HOTORO MINI'
        },
        {
            SOL_ID: '68',
            Branch_Name: 'IBADAN MAIN'
        },
        {
            SOL_ID: '69',
            Branch_Name: 'IDEJO'
        },
        {
            SOL_ID: '70',
            Branch_Name: 'IDUMAGBO'
        },
        {
            SOL_ID: '71',
            Branch_Name: 'IFE'
        },
        {
            SOL_ID: '72',
            Branch_Name: 'IGANDO'
        },
        {
            SOL_ID: '73',
            Branch_Name: 'IJEBU ODE'
        },
        {
            SOL_ID: '74',
            Branch_Name: 'IKEJA CITY MALL'
        },
        {
            SOL_ID: '75',
            Branch_Name: 'IKORODU'
        },
        {
            SOL_ID: '76',
            Branch_Name: 'IKOTA'
        },
        {
            SOL_ID: '77',
            Branch_Name: 'IKOTUN BRANCH'
        },
        {
            SOL_ID: '78',
            Branch_Name: 'ILESHA'
        },
        {
            SOL_ID: '79',
            Branch_Name: 'ILORIN'
        },
        {
            SOL_ID: '80',
            Branch_Name: 'IPAJA BRANCH'
        },
        {
            SOL_ID: '81',
            Branch_Name: 'IWO ROAD (IBADAN)'
        },
        {
            SOL_ID: '82',
            Branch_Name: 'IWO TOWN'
        },
        {
            SOL_ID: '83',
            Branch_Name: 'IYANA CHURCH'
        },
        {
            SOL_ID: '84',
            Branch_Name: 'JALINGO'
        },
        {
            SOL_ID: '85',
            Branch_Name: 'JOS'
        },
        {
            SOL_ID: '86',
            Branch_Name: 'KACHIA MINI'
        },
        {
            SOL_ID: '87',
            Branch_Name: 'KADUNA'
        },
        {
            SOL_ID: '88',
            Branch_Name: 'KADUNA CENTRAL MINI'
        },
        {
            SOL_ID: '90',
            Branch_Name: 'KADUNA NNPC'
        },
        {
            SOL_ID: '91',
            Branch_Name: 'KANO'
        },
        {
            SOL_ID: '92',
            Branch_Name: 'KANO SERVICE CENTRE'
        },
        {
            SOL_ID: '93',
            Branch_Name: 'KANTIN KWARI'
        },
        {
            SOL_ID: '94',
            Branch_Name: 'KARIMU KOTUN'
        },
        {
            SOL_ID: '95',
            Branch_Name: 'KASUWAR BARCI'
        },
        {
            SOL_ID: '96',
            Branch_Name: 'KATSINA'
        },
        {
            SOL_ID: '98',
            Branch_Name: 'KAWO-MANDO'
        },
        {
            SOL_ID: '99',
            Branch_Name: 'KEBBI'
        },
        {
            SOL_ID: '100',
            Branch_Name: 'KETU MINI'
        },
        {
            SOL_ID: '102',
            Branch_Name: 'KONTANGORA'
        },
        {
            SOL_ID: '103',
            Branch_Name: 'KUBWA MINI'
        },
        {
            SOL_ID: '104',
            Branch_Name: 'KWARA MALL'
        },
        {
            SOL_ID: '105',
            Branch_Name: 'LAFIA'
        },
        {
            SOL_ID: '106',
            Branch_Name: 'LAWANSON MINI'
        },
        {
            SOL_ID: '108',
            Branch_Name: 'LEKKI 1'
        },
        {
            SOL_ID: '109',
            Branch_Name: 'LEKKI 2'
        },
        {
            SOL_ID: '110',
            Branch_Name: 'LEKKI ADMIRALTY'
        },
        {
            SOL_ID: '111',
            Branch_Name: 'LOKOJA'
        },
        {
            SOL_ID: '112',
            Branch_Name: 'MAIDUGURI'
        },
        {
            SOL_ID: '113',
            Branch_Name: 'MAITAMA'
        },
        {
            SOL_ID: '114',
            Branch_Name: 'MAKURDI'
        },
        {
            SOL_ID: '115',
            Branch_Name: 'MARARABA MINI'
        },
        {
            SOL_ID: '116',
            Branch_Name: 'MARYLAND BRANCH'
        },
        {
            SOL_ID: '117',
            Branch_Name: 'MAUTECH'
        },
        {
            SOL_ID: '119',
            Branch_Name: 'MINNA'
        },
        {
            SOL_ID: '120',
            Branch_Name: 'MOKOLA'
        },
        {
            SOL_ID: '121',
            Branch_Name: 'MURITALA MOHAMMED AIRPORT'
        },
        {
            SOL_ID: '122',
            Branch_Name: 'MUSHIN'
        },
        {
            SOL_ID: '123',
            Branch_Name: 'NEW BENIN MINI'
        },
        {
            SOL_ID: '124',
            Branch_Name: 'NEW GBAGI MINI'
        },
        {
            SOL_ID: '125',
            Branch_Name: 'NIGERIAN IMMIGRATION SERVICE'
        },
        {
            SOL_ID: '126',
            Branch_Name: 'NIGERIAN PORTS AUTHORITY'
        },
        {
            SOL_ID: '127',
            Branch_Name: 'NYANYAN'
        },
        {
            SOL_ID: '128',
            Branch_Name: 'OBA AKRAN AVENUE'
        },
        {
            SOL_ID: '130',
            Branch_Name: 'OGBA'
        },
        {
            SOL_ID: '131',
            Branch_Name: 'OGBOMOSHO'
        },
        {
            SOL_ID: '132',
            Branch_Name: 'OGUDU'
        },
        {
            SOL_ID: '133',
            Branch_Name: 'OJATUNTUN'
        },
        {
            SOL_ID: '134',
            Branch_Name: 'OJODU'
        },
        {
            SOL_ID: '135',
            Branch_Name: 'OJUWOYE MINI'
        },
        {
            SOL_ID: '136',
            Branch_Name: 'OKE ARIN MINI'
        },
        {
            SOL_ID: '137',
            Branch_Name: 'OKO OBA MINI'
        },
        {
            SOL_ID: '138',
            Branch_Name: 'OKOTA'
        },
        {
            SOL_ID: '139',
            Branch_Name: 'OLU OBASANJO P/H'
        },
        {
            SOL_ID: '141',
            Branch_Name: 'ONDO'
        },
        {
            SOL_ID: '142',
            Branch_Name: 'ONITSHA'
        },
        {
            SOL_ID: '143',
            Branch_Name: 'ONITSHA MINI'
        },
        {
            SOL_ID: '144',
            Branch_Name: 'OPEBI'
        },
        {
            SOL_ID: '145',
            Branch_Name: 'ORILE COKER'
        },
        {
            SOL_ID: '146',
            Branch_Name: 'OSHODI'
        },
        {
            SOL_ID: '147',
            Branch_Name: 'OSHOGBO'
        },
        {
            SOL_ID: '148',
            Branch_Name: 'OSOLO'
        },
        {
            SOL_ID: '149',
            Branch_Name: 'OTUKPO'
        },
        {
            SOL_ID: '150',
            Branch_Name: 'OWERRI'
        },
        {
            SOL_ID: '151',
            Branch_Name: 'OYIGBO'
        },
        {
            SOL_ID: '152',
            Branch_Name: 'OYINGBO MINI'
        },
        {
            SOL_ID: '153',
            Branch_Name: 'OYO'
        },
        {
            SOL_ID: '154',
            Branch_Name: 'P/H AIRPORT'
        },
        {
            SOL_ID: '155',
            Branch_Name: 'POLO MALL'
        },
        {
            SOL_ID: '157',
            Branch_Name: 'PORT HARCOURT SERVICE CENTRE'
        },
        {
            SOL_ID: '158',
            Branch_Name: 'RING ROAD'
        },
        {
            SOL_ID: '159',
            Branch_Name: 'SABON GARI - ZARIA'
        },
        {
            SOL_ID: '160',
            Branch_Name: 'SABON GARI-KANO'
        },
        {
            SOL_ID: '161',
            Branch_Name: 'SABON TASHA'
        },
        {
            SOL_ID: '162',
            Branch_Name: 'SAKI'
        },
        {
            SOL_ID: '163',
            Branch_Name: 'SANGO-OTTA'
        },
        {
            SOL_ID: '164',
            Branch_Name: 'SANGO-OTTA 2'
        },
        {
            SOL_ID: '165',
            Branch_Name: 'SAPELE ROAD'
        },
        {
            SOL_ID: '166',
            Branch_Name: 'SAPON MINI'
        },
        {
            SOL_ID: '167',
            Branch_Name: 'SATELLITE'
        },
        {
            SOL_ID: '169',
            Branch_Name: 'SHAGAMU'
        },
        {
            SOL_ID: '170',
            Branch_Name: 'SHAUCHI'
        },
        {
            SOL_ID: '171',
            Branch_Name: 'SHOMOLU'
        },
        {
            SOL_ID: '172',
            Branch_Name: 'SOKOTO'
        },
        {
            SOL_ID: '173',
            Branch_Name: 'SULEJA'
        },
        {
            SOL_ID: '174',
            Branch_Name: 'SURULERE'
        },
        {
            SOL_ID: '175',
            Branch_Name: 'TEJUOSHO'
        },
        {
            SOL_ID: '176',
            Branch_Name: 'TOWER MALL'
        },
        {
            SOL_ID: '177',
            Branch_Name: 'TOYIN STREET'
        },
        {
            SOL_ID: '178',
            Branch_Name: 'TRADE FAIR'
        },
        {
            SOL_ID: '179',
            Branch_Name: 'TRANS AMADI - P/H'
        },
        {
            SOL_ID: '180',
            Branch_Name: 'TRANS AMADI 2 BRANCH'
        },
        {
            SOL_ID: '181',
            Branch_Name: 'UI ROAD'
        },
        {
            SOL_ID: '182',
            Branch_Name: 'UMUAHIA'
        },
        {
            SOL_ID: '183',
            Branch_Name: 'UNIBEN'
        },
        {
            SOL_ID: '184',
            Branch_Name: 'UTAKO BRANCH'
        },
        {
            SOL_ID: '185',
            Branch_Name: 'UYO BRANCH'
        },
        {
            SOL_ID: '186',
            Branch_Name: 'WAREHOUSE ROAD, APAPA'
        },
        {
            SOL_ID: '187',
            Branch_Name: 'WARRI'
        },
        {
            SOL_ID: '188',
            Branch_Name: 'WHATT MINI'
        },
        {
            SOL_ID: '189',
            Branch_Name: 'WUSE 2'
        },
        {
            SOL_ID: '191',
            Branch_Name: 'YENEGOA'
        },
        {
            SOL_ID: '192',
            Branch_Name: 'YINKA FOLAWIYO PLAZA, APAPA'
        },
        {
            SOL_ID: '193',
            Branch_Name: 'YOLA'
        },
        {
            SOL_ID: '196',
            Branch_Name: 'ZARIA'
        },
        {
            SOL_ID: '198',
            Branch_Name: 'ZARIA CITY MINI'
        }
    ];

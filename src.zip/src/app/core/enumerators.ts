
export enum ResponseCodes {
    SUCCESS = '00',
}

export enum Role {
    Initiator = 2,
    Viewer = 4,
    Approver = 8,
    Retail = 0
}
